
URLCONFIG = {

        'python.org': 'https://www.python.org/ '

}